# Nodejs web app

Express app that counts web site visits and stores in a default Redis backend.
